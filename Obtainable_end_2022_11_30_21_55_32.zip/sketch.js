  let fr = 60;
  let mousepx = 0;
    let mousepy = 0;
   let mouseprex = 0;
   let mouseprey = 0;
function setup() {
  createCanvas(400, 400);
   frameRate(fr);
}

function draw() {
  colorMode(RGB, 255, 255, 255, 1);
  background(220);
  mousepx = mouseX
  mousepy = mouseY
  mouseprex = pmouseX
  mouseprey = pmouseY
  let d = dist(mousepx, mousepy, 10, 10);
  if(mousepx>mouseprex){
    fill(255, pow(mousepx), 100);
    ellipse(mousepx, mousepy, 50, 50)
  }
  if(mousepy>mouseprey){
   fill(255, 204, mousepy);
   rect(mousepx, mousepy, 50, 50);
  }
   if(d > 300){
   fill(51);
   
  }
  
}