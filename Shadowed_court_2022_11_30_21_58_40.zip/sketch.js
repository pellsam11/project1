let screencolorR = 0
let screencolorG = 0
let screencolorB = 0
let button
let posDist = 1000;
let posDist2 = 1000;

let posX = 0;

let eX = 350;
let eY = 350;
let eR = 50;
let eX2 = 275;
let eY2 = 350;
let eR2 = 50;
let mouseWasClicked = false;
let keyWasPressed = false;
function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
    button = createButton('change channel');
  button.position(50, 335);
  button.mousePressed(changechannel);
}

function mouseClicked() {
  if(posDist < eR) {
    mouseWasClicked = true;
  }
}
function changechannel() {
  screencolorR = random(255);
   screencolorG = random(255);
   screencolorB = random(255);
  

}
function keyPressed() {
 if(posDist2 < eR2) {
    keyWasPressed = true;
  }
}
function draw() {
   if(mouseWasClicked === true){
     screencolorR = 0
      screencolorG = 0
      screencolorB = 0
     mouseWasClicked = false
   }
   if(keyWasPressed === true){
     screencolorR += 1
      screencolorG = 0
      screencolorB = 0
    
    
   }
  
  background(220);
  fill(100, 50, 0);
  rect(0,0, 400, 400)
  fill(screencolorR, screencolorG, screencolorB);
  rect(50, 50, 300, 150);
   fill(100, 100, 100);
   rect(0, 300, 400, 100);
  fill(255, 0,0)
   ellipse(eX, eY, eR, eR);
  posDist = dist(mouseX, mouseY, eX, eY);
   fill(0, 0,255)
   ellipse(eX2, eY2, eR2, eR2);
  posDist2 = dist(mouseX, mouseY, eX2, eY2);
  
  
}